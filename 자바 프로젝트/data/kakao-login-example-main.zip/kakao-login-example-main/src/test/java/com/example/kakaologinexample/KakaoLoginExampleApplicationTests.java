package com.example.kakaologinexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KakaoLoginExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
