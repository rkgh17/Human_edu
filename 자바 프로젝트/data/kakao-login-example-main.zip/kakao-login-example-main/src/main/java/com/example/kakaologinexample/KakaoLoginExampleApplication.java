package com.example.kakaologinexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KakaoLoginExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(KakaoLoginExampleApplication.class, args);
	}

}
