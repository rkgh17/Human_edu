# 20221011 
# 1. 디스페처 서블릿과 springboot 전반적인 흐름
# 2. conda 가상환경
# 3. pandas dataframe
# 4. 사이킷런 프레임워크를 사용한 iris꽃 분류 머신러닝

def test() :
    print("hello world")

test()